// imports:
import {removeProductsFromLs} from './localStorage.js';
import showAllLsProducts from './showAllLsProducts.js';
import {getProductsFromLs} from './localStorage.js';

// dom elements:
const cartProductsContainer = document.getElementById('cartProductsContainer');

// create product cart:
function createProductCart(productData, quantity) {
    const productEl = document.createElement('li');
    productEl.className = 'product';
    let productElStr = `
        <div class="info-box">
            <img class="img-fluid"
            src=${productData.baseImgSrc}
            alt=${productData.title}>
            <div class="text"> 
                <a href="#">${productData.title}</a>
                <span>${quantity} x $${productData.price}</span>
            </div>
        </div>
        <a class="delete-btn" href="#">
            <i class="fa fa-trash-alt"></i>
        </a>
    `;
    productEl.innerHTML = productElStr;

    const deleteBtn = productEl.querySelector('.delete-btn');
    deleteBtn.addEventListener('click', _ => {
        removeProductsFromLs(productData);
        showAllLsProducts();
    });

    cartProductsContainer.appendChild(productEl);
}

export default createProductCart;