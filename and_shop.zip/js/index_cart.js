import showAllLsProducts from './showAllLsProducts.js';

// create products cart:
showAllLsProducts(1, true);